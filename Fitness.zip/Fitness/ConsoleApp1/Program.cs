﻿using System.Runtime.CompilerServices;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            list.Add(1);
            list.Add(2);

            list.Remove(1);

            Console.WriteLine("asalama lijkum");
        }
    }
}
