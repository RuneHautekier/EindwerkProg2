﻿namespace FitnessAPI.DTO
{
    public class TrainingSessionMemberAantalPerMaandInJaarMetTypeDTO
    {
        public Dictionary<string, Dictionary<string, string>> SessiesPerMaand { get; set; }
    }
}
