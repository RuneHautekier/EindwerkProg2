﻿namespace FitnessAPI.DTO
{
    public class TrainingSessionMemberSessiesAantalPerMaandDTO
    {
        public Dictionary<string, string> SessiesPerMaand { get; set; }
    }
}
