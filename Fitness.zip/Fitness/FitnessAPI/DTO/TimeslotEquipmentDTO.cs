﻿namespace FitnessAPI.DTO
{
    public class TimeslotEquipmentDTO
    {
        public int Time_slot_id { get; set; }
        public int Equipment_id { get; set; }
    }
}
