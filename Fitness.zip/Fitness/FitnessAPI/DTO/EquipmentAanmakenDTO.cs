﻿namespace FitnessAPI.DTO
{
    public class EquipmentAanmakenDTO
    {
        public string device_type { get; set; }
    }
}
