﻿namespace FitnessAPI.DTO
{
    public class EquipmentOnderhoudDTO
    {
        public int EquipmentId { get; set; }
    }
}
